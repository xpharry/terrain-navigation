# models

A dummy ROS package to hold gazebo models locally, as well as launch files to import models into gazebo

## Example usage
roslaunch exmpl_models add_starting_pen.launch

    
